create function check_quantity_not_negative() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT' OR TG_OP = 'UPDATE') AND (NEW.quantity < 0) THEN
        RAISE EXCEPTION 'Quantity cannot be less than 0';
    END IF;

    IF TG_OP = 'UPDATE' THEN
        PERFORM * FROM information_system_trading_org.items_stock_outlets
        WHERE id = OLD.id AND (OLD.quantity + NEW.quantity < 0);
        IF FOUND THEN
            RAISE EXCEPTION 'Quantity cannot be less than 0';
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function check_quantity_not_negative() owner to postgres;

