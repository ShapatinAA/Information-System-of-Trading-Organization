create function handle_items_stock_supplier_insert() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Check if a row with the same product_id and supplier_id exists
    IF EXISTS (
        SELECT 1
        FROM information_system_trading_org.items_stock_suppliers
        WHERE product_id = NEW.product_id AND supplier_id = NEW.supplier_id
    ) THEN
        -- Update the existing row: set new price
        UPDATE information_system_trading_org.items_stock_suppliers
        SET
            price = NEW.price
        WHERE
            product_id = NEW.product_id AND supplier_id = NEW.supplier_id;
        -- Prevent insertion of the new row
        RETURN NULL;
    ELSE
        -- Proceed with the insertion of the new row
        RETURN NEW;
    END IF;
END;
$$;

alter function handle_items_stock_supplier_insert() owner to postgres;

