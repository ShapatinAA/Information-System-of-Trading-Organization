create function handle_items_stock_outlet_insert() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Check if a row with the same product_id and outlet_id exists
    IF EXISTS (
        SELECT 1
        FROM information_system_trading_org.items_stock_outlets
        WHERE product_id = NEW.product_id AND outlet_id = NEW.outlet_id
    ) THEN
        -- Update the existing row: add quantity and set new price
        UPDATE information_system_trading_org.items_stock_outlets
        SET
            quantity = quantity + NEW.quantity,
            price = NEW.price
        WHERE
            product_id = NEW.product_id AND outlet_id = NEW.outlet_id;
        -- Prevent insertion of the new row
        RETURN NULL;
    ELSE
        -- Proceed with the insertion of the new row
        RETURN NEW;
    END IF;
END;
$$;

alter function handle_items_stock_outlet_insert() owner to postgres;

