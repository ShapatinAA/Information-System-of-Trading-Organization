create function handle_transfer_fulfillment() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Check if the transfer status is being updated to "fulfilled"
    IF NEW.status = 'fulfilled' THEN
        -- Decrease the quantity in the outlet_id_from
        UPDATE information_system_trading_org.items_stock_outlets
        SET quantity = quantity - NEW.amount
        WHERE product_id = NEW.product_id AND outlet_id = NEW.outlet_id_from;

        -- Increase the quantity in the outlet_id_to
        IF EXISTS (
            SELECT 1
            FROM information_system_trading_org.items_stock_outlets
            WHERE product_id = NEW.product_id AND outlet_id = NEW.outlet_id_to
        ) THEN
            -- Update the existing item in stock
            UPDATE information_system_trading_org.items_stock_outlets
            SET quantity = quantity + NEW.amount
            WHERE product_id = NEW.product_id AND outlet_id = NEW.outlet_id_to;
        ELSE
            -- Insert a new item in stock
            INSERT INTO information_system_trading_org.items_stock_outlets (product_id, outlet_id, quantity, price)
            VALUES (
                       NEW.product_id,
                       NEW.outlet_id_to,
                       NEW.amount,
                       (SELECT price FROM information_system_trading_org.items_stock_outlets WHERE product_id = NEW.product_id AND outlet_id = NEW.outlet_id_from LIMIT 1) -- Use the price from the outlet_id_from
                   );
        END IF;
    END IF;

    RETURN NEW;
END;
$$;

alter function handle_transfer_fulfillment() owner to postgres;

