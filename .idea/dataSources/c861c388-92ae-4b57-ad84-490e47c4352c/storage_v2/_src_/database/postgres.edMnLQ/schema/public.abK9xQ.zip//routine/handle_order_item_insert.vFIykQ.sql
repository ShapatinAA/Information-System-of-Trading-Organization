create function handle_order_item_insert() returns trigger
    language plpgsql
as
$$
DECLARE
    supplier_price FLOAT;
BEGIN
    -- Fetch the supplier's price for the product
    SELECT price INTO supplier_price
    FROM information_system_trading_org.items_stock_suppliers
    WHERE product_id = NEW.product_id AND supplier_id = NEW.supplier_id
    LIMIT 1;

    -- Mark the corresponding request as fulfilled
    UPDATE information_system_trading_org.requests
    SET status = 'fulfilled'
    WHERE id = NEW.request_id;

    -- Check if the product already exists in the items_stock_outlets
    IF EXISTS (
        SELECT 1
        FROM information_system_trading_org.items_stock_outlets
        WHERE product_id = NEW.product_id AND outlet_id = (SELECT outlet_id FROM information_system_trading_org.requests WHERE id = NEW.request_id)
    ) THEN
        -- Update the existing item in stock
        UPDATE information_system_trading_org.items_stock_outlets
        SET quantity = quantity + NEW.quantity
        WHERE product_id = NEW.product_id AND outlet_id = (SELECT outlet_id FROM information_system_trading_org.requests WHERE id = NEW.request_id);
    ELSE
        -- Insert a new item in stock with the supplier's price
        INSERT INTO information_system_trading_org.items_stock_outlets (product_id, outlet_id, quantity, price)
        VALUES (
                   NEW.product_id,
                   (SELECT outlet_id FROM information_system_trading_org.requests WHERE id = NEW.request_id),
                   NEW.quantity,
                   COALESCE(supplier_price, 0)  -- Use supplier's price if available, otherwise 0
               );
    END IF;

    RETURN NEW;
END;
$$;

alter function handle_order_item_insert() owner to postgres;

