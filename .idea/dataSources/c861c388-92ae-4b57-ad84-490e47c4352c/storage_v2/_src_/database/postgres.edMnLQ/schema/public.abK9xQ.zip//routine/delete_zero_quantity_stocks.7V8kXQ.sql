create function delete_zero_quantity_stocks() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.quantity = 0 THEN
        DELETE FROM information_system_trading_org.items_stock_outlets WHERE id = NEW.id;
    END IF;
    RETURN NEW;
END;
$$;

alter function delete_zero_quantity_stocks() owner to postgres;

