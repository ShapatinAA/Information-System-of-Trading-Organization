create function prevent_duplicate_sales() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (
        SELECT 1
        FROM information_system_trading_org.sales
        WHERE human_id = NEW.human_id
          AND product_id = NEW.product_id
          AND outlet_id = NEW.outlet_id
          AND date = NEW.date
          AND price = NEW.price
          AND quantity = NEW.quantity
    ) THEN
        RAISE EXCEPTION 'Duplicate sale entry is not allowed';
    END IF;

    RETURN NEW;
END;
$$;

alter function prevent_duplicate_sales() owner to postgres;

