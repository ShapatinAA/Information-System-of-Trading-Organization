create function update_stock_after_sale() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE information_system_trading_org.items_stock_outlets
    SET quantity = quantity - NEW.quantity
    WHERE product_id = NEW.product_id AND outlet_id = NEW.outlet_id;

    RETURN NEW;
END;
$$;

alter function update_stock_after_sale() owner to postgres;

